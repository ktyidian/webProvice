var w = window.innerWidth;
var h = window.innerHeight;

$(document).ready(function() {

	var lis = $(".tempWrap .commonList_dot").children("li.nowrap");
	var li_w = $(".page").width();
	lis.each(function() {
		$(this).css("width",li_w - 14);
	});

        var f_img = $("#focus .tempWrap li a.pic");
	var f_img_w = $(".page").width();
	var f_h = f_img_w * 0.64;
	f_img.each(function(){

		$(this).find("img").css("height",f_h);

	})
 

	var echart = $(".hot-echart #echarts");
	var ec_w = $(".page").width();
	var h = $(".hot-echart").width() * 0.5625;
	//echart.css("height", h);
	echart.css("width", ec_w);
	
	var top_img = $("#new2 .commonList_dot li.top-img");
	var img_w = $(".page").width();
	var h = (img_w-24)/2 * 0.5625;
	top_img.each(function(){
		$(this).find("img").css("height",h);
	})	


    var f4_img = $("#banner .bd ul li a");
	var f4_img_w = $(".page").width();
	var f4_h = f4_img_w * 0.186;
	f4_img.each(function(){

		$(this).find("img").css("height",f4_h);

	})

      $(".tabBox .hd li a").click(function(event){ event.preventDefault(); });

	
	$("#topscolle").click(function() {
		$('html,body').animate({
			'scrollTop': 0
		}, 600);
	});

	$(".history").click(function() {
		window.history.go(-1); //返回上一页不刷新  
		window.location.href = document.referrer; //返回上一页并刷新  
		$(".page").addClass('animated fadeInLeft');
	});


});



window.onload = function() {
	setInterval(function() {
		$(window).bind('scroll resize', function() {
			if($(window).scrollTop() <= 300) {
				$("#topscolle").hide();
			} else {
				$("#topscolle").show();
			}
		})
	}, 1000);

}